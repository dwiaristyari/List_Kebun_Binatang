package info.binatang;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> fotoBinatang = new ArrayList<>();
    private ArrayList<String> namaBinatang = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();

    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(fotoBinatang,namaBinatang,this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void getDataFromInternet(){

        namaBinatang.add("Buaya Amerika");
        fotoBinatang.add("https://www.ekor9.com/wp-content/uploads/2019/09/hewan-yang-hidup-di-darat-dan-air-adalah.jpg");

        namaBinatang.add("Kura-kura berbintik/ Spotted Turtles");
        fotoBinatang.add("https://www.ekor9.com/wp-content/uploads/2019/09/jenis-hewan-darat-dan-air.jpg");

        namaBinatang.add("Salamander bergaris dua");
        fotoBinatang.add("https://www.ekor9.com/wp-content/uploads/2019/09/hewan-hidup-di-darat-dan-air-disebut-amfibi.jpg");

        prosesRecyclerViewAdapter();


    }
}
